public class GregorianDate extends Date {

    public static void main(String[] args) {

    }

    // Uses the Date class to implement the Gregorian Calendar
    public GregorianDate() {
        super(1970, 1, 1);

        long numMilliSinceEpoch = System.currentTimeMillis();
        long myTimeZoneMillis = numMilliSinceEpoch + java.util.TimeZone.getDefault().getRawOffset();
        long numSeconds = myTimeZoneMillis / 1000;
        long numMinutes = numSeconds / 60;
        int daysSinceEpoch = (int)numMinutes / 1440;

        addDays(daysSinceEpoch);
    }

    // Allows the user to change the Gregorian Calendar date to any date they wish
    public GregorianDate(int year, int month, int date) {
        super(year, month, date);
    }

    // Provides the correct implementation for the way that the Gregorian Calendar calculates leap
    // years
    @Override
    boolean isLeapYear(int year) {
        return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0));
    }
}
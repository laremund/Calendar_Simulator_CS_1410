public abstract class Date {
    public static void main(String[] args) {

    }

    private int dayOfMonth;
    private int month;
    private int year;


    public Date() {}

    // Sets the date to whatever day you wish
    public Date(int year, int month, int date) {
        this.year = year;
        this.month = month;
        this.dayOfMonth = date;
    }

    // Add a given number of days to any date and modify dayOfMonth, month, and year
    void addDays(int days) {

        for (int i = 0; i < days; i++) {
            dayOfMonth ++;
            if (dayOfMonth > getNumberOfDaysInMonth(year, month)) {
                dayOfMonth = 1;
                month ++;
                if (month == 13) {
                    month = 1;
                    year++;
                }
            }
        }
    }

    // Subtract a given number of days to any date and modify dayOfMonth, month, and year
    void subtractDays(int days) {
        // Same as above, this could be very small or very big
        for (int i = 0; i < days; i++) {
            dayOfMonth--;
            if (dayOfMonth < 1) {
                month --;
                if (month < 1) {
                    month = 12;
                    year --;
                }
                dayOfMonth = getNumberOfDaysInMonth(year, month);
            }
        }
    }

    // Accesses the private method that determines whether a year is a leap year or not
    boolean isLeapYear() {
        return isLeapYear(year);
    }

    // Prints date in ##/##/#### form
    void printShortDate() {
        System.out.printf("%2d/%1d/%4d", month, dayOfMonth, year);
    }
    // Prints date in monthName day, year form
    void printLongDate() { System.out.printf("%9s %1d, %4d", getMonthName(), dayOfMonth, year); }
    String getMonthName() { return getMonthName(month); }
    int getMonth() { return month; }
    int getYear() { return year; }
    int getDayOfMonth() { return dayOfMonth; }

    // This is a method meant to be overridden based on what type of calendar is implementing the
    // date class
    abstract boolean isLeapYear(int year);

    private int getNumberOfDaysInMonth(int year, int month) {
        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            case 2:
                if (isLeapYear(year)) {
                    return 29;
                } else {
                    return 28;
                }
        }
        return 0;
    }

    private String getMonthName(int month) {
        if (month == 1) {
            return "January";
        } else if (month == 2) {
            return "February";
        } else if (month == 3) {
            return "March";
        } else if (month == 4) {
            return "April";
        } else if (month == 5) {
            return "May";
        } else if (month == 6) {
            return "June";
        } else if (month == 7) {
            return "July";
        } else if (month == 8) {
            return "August";
        } else if (month == 9) {
            return "September";
        } else if (month == 10) {
            return "October";
        } else if (month == 11) {
            return "November";
        } else if (month == 12) {
            return "December";
        } else {
            return "Invalid Entry";
        }
    }
}
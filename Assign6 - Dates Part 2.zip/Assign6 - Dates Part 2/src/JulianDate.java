public class JulianDate extends Date {

    public static void main(String[] args) {

    }

    // Uses the Date class to implement the Julian Calendar
    public JulianDate() {
        super(1, 1, 1);

        int beforeEpochDays = 719164;

        long numMilliSinceEpoch = System.currentTimeMillis();
        long myTimeZoneMillis = numMilliSinceEpoch + java.util.TimeZone.getDefault().getRawOffset();
        long numSeconds = myTimeZoneMillis / 1000;
        long numMinutes = numSeconds / 60;
        int daysSinceEpoch = (int)numMinutes / 1440;

        addDays(beforeEpochDays + daysSinceEpoch);
    }

    // Allows the user to change the Julian Calendar date to any date they wish
    public JulianDate(int year, int month, int date) {
        super(year, month, date);
    }

    // Provides the correct implementation for the way the Julian Calendar calculates leap years
    @Override
    boolean isLeapYear(int year) {
        return (year % 4 == 0 );
    }
}